# AtomScape - Interactive Chemistry Lab

Created by **ISWATHI T**

- Element Explorer: all 118 elements with a 2D Bohr model and a rotatable 3D atom
- Molecule Lab: SMILES or compound name -> 2D drawing, 3D model, descriptors (RDKit + py3Dmol)
- ChemBot: AI chemistry tutor for doubts

## Run locally
```bash
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .streamlit/secrets.toml.example .streamlit/secrets.toml   # then add your API key
streamlit run app.py
```

## Deploy (Streamlit Community Cloud, free)
1. Push this folder to a GitHub repository.
2. Go to share.streamlit.io, click "Create app", pick the repo, branch `main`, file `app.py`.
3. In Advanced settings, choose Python 3.11 and paste into Secrets:
   `ANTHROPIC_API_KEY = "your-key"`
4. Click Deploy.
