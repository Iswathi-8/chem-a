"""
AtomScape - Interactive Chemistry Lab
Created by ISWATHI T
"""
import math
import os

import numpy as np
import plotly.graph_objects as go
import streamlit as st
import streamlit.components.v1 as components

# ----------------------------------------------------------------------------
# Page setup
# ----------------------------------------------------------------------------
st.set_page_config(
    page_title="AtomScape | Interactive Chemistry Lab",
    page_icon="🧪",
    layout="wide",
    initial_sidebar_state="expanded",
)

CREATOR = "ISWATHI T"

BLOCK_COLORS = {"s": "#E4572E", "p": "#0E7C86", "d": "#3F51B5", "f": "#D99A00"}
BLOCK_NAMES = {
    "s": "s-block (alkali & alkaline earth)",
    "p": "p-block (main group)",
    "d": "d-block (transition metals)",
    "f": "f-block (lanthanides & actinides)",
}

CSS = """
<style>
@import url('https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@500;700&family=DM+Sans:wght@400;500;700&display=swap');
html, body, [class*="css"], .stMarkdown, p, label { font-family: 'DM Sans', sans-serif; }
h1, h2, h3, h4 { font-family: 'Space Grotesk', sans-serif !important; letter-spacing: -0.02em; color: #14213D; }
.block-container { padding-top: 2rem; padding-bottom: 4rem; max-width: 1250px; }
[data-testid="stSidebar"] { background: #14213D; }
[data-testid="stSidebar"] * { color: #EAF0F7 !important; }
[data-testid="stSidebar"] hr { border-color: rgba(255,255,255,.15); }

.hero { background: linear-gradient(120deg, #14213D 0%, #0E7C86 100%); border-radius: 22px;
        padding: 3rem 2.6rem; color: #fff; margin-bottom: 1.6rem; }
.hero h1 { color: #fff; font-size: 3rem; margin: 0 0 .4rem 0; line-height: 1.05; }
.hero p { font-size: 1.12rem; max-width: 640px; opacity: .92; margin: 0; }
.hero .by { margin-top: 1.4rem; font-size: .95rem; opacity: .8; }

.card { background: #fff; border: 1px solid #E3E9F1; border-radius: 16px; padding: 1.3rem 1.4rem; height: 100%; }
.card h4 { margin: 0 0 .4rem 0; font-size: 1.1rem; }
.card p { margin: 0; color: #4A5A70; font-size: .95rem; }

.chip { display:inline-block; padding: .25rem .7rem; border-radius: 999px; font-size: .8rem;
        font-weight: 700; color: #fff; margin-right: .4rem; }
.stat { background:#fff; border:1px solid #E3E9F1; border-radius:14px; padding:.9rem 1rem; }
.stat .k { font-size:.8rem; color:#6B7A90; }
.stat .v { font-family:'Space Grotesk'; font-size:1.25rem; font-weight:700; color:#14213D; }
.footer { text-align:center; color:#6B7A90; font-size:.9rem; margin-top:3rem; padding-top:1.2rem;
          border-top:1px solid #E3E9F1; }
.footer b { color:#14213D; }
.stButton>button { border-radius: 10px; font-weight: 600; }
@media (max-width: 700px) { .hero h1 { font-size: 2.1rem; } .hero { padding: 2rem 1.4rem; } }
</style>
"""
st.markdown(CSS, unsafe_allow_html=True)


def footer():
    st.markdown(
        f'<div class="footer">Designed and developed by <b>{CREATOR}</b></div>',
        unsafe_allow_html=True,
    )


# ----------------------------------------------------------------------------
# Element data
# ----------------------------------------------------------------------------
MADELUNG = [(1, "s", 2), (2, "s", 2), (2, "p", 6), (3, "s", 2), (3, "p", 6), (4, "s", 2),
            (3, "d", 10), (4, "p", 6), (5, "s", 2), (4, "d", 10), (5, "p", 6), (6, "s", 2),
            (4, "f", 14), (5, "d", 10), (6, "p", 6), (7, "s", 2), (5, "f", 14), (6, "d", 10),
            (7, "p", 6)]


def madelung_shells(z):
    shells, left = {}, z
    for n, _, cap in MADELUNG:
        if left <= 0:
            break
        put = min(cap, left)
        shells[n] = shells.get(n, 0) + put
        left -= put
    return [shells[k] for k in sorted(shells)]


@st.cache_data(show_spinner=False)
def load_elements():
    from mendeleev import get_all_elements

    rows = []
    for el in get_all_elements():
        z = el.atomic_number
        shells = None
        try:
            tmp = {}
            for (n, _l), c in el.ec.conf.items():
                tmp[n] = tmp.get(n, 0) + c
            shells = [tmp[k] for k in sorted(tmp)]
            if sum(shells) != z:
                shells = None
        except Exception:
            shells = None
        if shells is None:
            shells = madelung_shells(z)

        def safe(fn, default=None):
            try:
                v = fn()
                return default if v is None else v
            except Exception:
                return default

        en = safe(lambda: el.electronegativity_pauling())
        if en is None:
            en = safe(lambda: el.en_pauling)

        rows.append(
            dict(
                z=z,
                symbol=el.symbol,
                name=el.name,
                mass=safe(lambda: float(el.atomic_weight)),
                period=safe(lambda: int(el.period)),
                group=safe(lambda: int(el.group_id)),
                block=safe(lambda: el.block, "s"),
                econf=safe(lambda: str(el.econf), ""),
                en=safe(lambda: float(en)),
                melt=safe(lambda: float(el.melting_point)),
                boil=safe(lambda: float(el.boiling_point)),
                density=safe(lambda: float(el.density)),
                desc=safe(lambda: el.description and str(el.description), ""),
                shells=shells,
            )
        )
    rows.sort(key=lambda r: r["z"])
    return rows


def fmt(v, unit=""):
    return "-" if v is None else f"{v:,.2f}".rstrip("0").rstrip(".") + unit


# ----------------------------------------------------------------------------
# Atom figures
# ----------------------------------------------------------------------------
def bohr_2d(el):
    shells = el["shells"]
    color = BLOCK_COLORS.get(el["block"], "#14213D")
    fig = go.Figure()
    t = np.linspace(0, 2 * math.pi, 200)
    for i, n_e in enumerate(shells, start=1):
        r = i
        fig.add_trace(go.Scatter(x=r * np.cos(t), y=r * np.sin(t), mode="lines",
                                 line=dict(color="#C5CFDD", width=1.5), hoverinfo="skip",
                                 showlegend=False))
        a = np.linspace(0, 2 * math.pi, n_e, endpoint=False) + i * 0.35
        fig.add_trace(go.Scatter(x=r * np.cos(a), y=r * np.sin(a), mode="markers",
                                 marker=dict(size=11, color="#14213D",
                                             line=dict(color="#fff", width=1.5)),
                                 hovertext=f"Shell {i}: {n_e} electrons", hoverinfo="text",
                                 showlegend=False))
    fig.add_trace(go.Scatter(x=[0], y=[0], mode="markers+text", text=[el["symbol"]],
                             textfont=dict(color="#fff", size=16),
                             marker=dict(size=46, color=color), hoverinfo="skip",
                             showlegend=False))
    lim = len(shells) + 0.6
    fig.update_xaxes(visible=False, range=[-lim, lim])
    fig.update_yaxes(visible=False, range=[-lim, lim], scaleanchor="x")
    fig.update_layout(height=470, margin=dict(l=0, r=0, t=10, b=0),
                      paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)")
    return fig


def _rot(p, ax, az):
    cx, sx, cz, sz = math.cos(ax), math.sin(ax), math.cos(az), math.sin(az)
    x, y, z = p
    y, z = y * cx - z * sx, y * sx + z * cx
    x, y = x * cz - y * sz, x * sz + y * cz
    return x, y, z


def atom_3d(el):
    shells = el["shells"]
    color = BLOCK_COLORS.get(el["block"], "#14213D")
    fig = go.Figure()
    t = np.linspace(0, 2 * math.pi, 160)
    for i, n_e in enumerate(shells, start=1):
        ax, az = 0.5 + i * 0.75, i * 1.1
        ring = np.array([_rot((i * math.cos(a), i * math.sin(a), 0), ax, az) for a in t])
        fig.add_trace(go.Scatter3d(x=ring[:, 0], y=ring[:, 1], z=ring[:, 2], mode="lines",
                                   line=dict(color="#B8C4D6", width=3), hoverinfo="skip",
                                   showlegend=False))
        a = np.linspace(0, 2 * math.pi, n_e, endpoint=False)
        pts = np.array([_rot((i * math.cos(v), i * math.sin(v), 0), ax, az) for v in a])
        fig.add_trace(go.Scatter3d(x=pts[:, 0], y=pts[:, 1], z=pts[:, 2], mode="markers",
                                   marker=dict(size=5, color="#14213D"),
                                   hovertext=f"Shell {i}: {n_e} electrons", hoverinfo="text",
                                   showlegend=False))
    fig.add_trace(go.Scatter3d(x=[0], y=[0], z=[0], mode="markers+text", text=[el["symbol"]],
                               textposition="middle center", textfont=dict(color="#fff", size=13),
                               marker=dict(size=22, color=color), hoverinfo="skip",
                               showlegend=False))
    lim = len(shells) + 0.5
    axis = dict(visible=False, range=[-lim, lim])
    fig.update_layout(height=470, margin=dict(l=0, r=0, t=0, b=0),
                      scene=dict(xaxis=axis, yaxis=axis, zaxis=axis, aspectmode="cube"),
                      paper_bgcolor="rgba(0,0,0,0)")
    return fig


def periodic_table(elements, selected_z):
    xs, ys, texts, colors, hover, sizes = [], [], [], [], [], []
    for el in elements:
        z = el["z"]
        if 57 <= z <= 71:
            x, y = 3 + (z - 57), -(7 + 1.4)
        elif 89 <= z <= 103:
            x, y = 3 + (z - 89), -(7 + 2.4)
        else:
            x, y = el["group"] or 1, -(el["period"] or 1)
        xs.append(x)
        ys.append(y)
        texts.append(el["symbol"])
        colors.append(BLOCK_COLORS.get(el["block"], "#888"))
        sizes.append(44 if z == selected_z else 36)
        hover.append(f"{el['name']} ({el['symbol']})<br>Atomic number {z}")
    fig = go.Figure(go.Scatter(
        x=xs, y=ys, mode="markers+text", text=texts, hovertext=hover, hoverinfo="text",
        textfont=dict(color="#fff", size=12),
        marker=dict(symbol="square", size=sizes, color=colors,
                    line=dict(color="#14213D", width=[3 if e["z"] == selected_z else 0 for e in elements]))))
    fig.update_xaxes(visible=False, range=[0.4, 18.6])
    fig.update_yaxes(visible=False, range=[-10.2, -0.4])
    fig.update_layout(height=470, margin=dict(l=0, r=0, t=0, b=0), clickmode="event+select",
                      paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)", dragmode=False)
    return fig


# ----------------------------------------------------------------------------
# Pages
# ----------------------------------------------------------------------------
def page_home():
    st.markdown(
        f"""
        <div class="hero">
          <h1>AtomScape</h1>
          <p>See every element of the periodic table in 2D and 3D, build molecules from a name or
          a SMILES string, and ask ChemBot whenever a concept does not click.</p>
          <div class="by">Created by {CREATOR}</div>
        </div>
        """,
        unsafe_allow_html=True,
    )
    c1, c2, c3 = st.columns(3)
    cards = [
        ("Element Explorer", "Click any of the 118 elements to see its Bohr model in 2D, a rotatable "
                             "atom in 3D, and key properties."),
        ("Molecule Lab", "Type a name like caffeine or a SMILES string. Get the 2D drawing, a 3D "
                         "model, and descriptors such as molecular weight and LogP."),
        ("ChemBot", "A chemistry tutor that explains bonding, reactions, periodic trends and more "
                    "in simple language."),
    ]
    for col, (h, p) in zip((c1, c2, c3), cards):
        col.markdown(f'<div class="card"><h4>{h}</h4><p>{p}</p></div>', unsafe_allow_html=True)
    st.write("")
    st.markdown("#### Colour guide")
    st.markdown(
        "".join(f'<span class="chip" style="background:{BLOCK_COLORS[b]}">{BLOCK_NAMES[b]}</span>'
                for b in "spdf"),
        unsafe_allow_html=True,
    )
    footer()


def page_elements():
    elements = load_elements()
    st.markdown("## Element Explorer")
    st.caption("Click an element in the table, or pick one from the list below it.")

    if "z" not in st.session_state:
        st.session_state.z = 6

    event = st.plotly_chart(periodic_table(elements, st.session_state.z), use_container_width=True,
                            on_select="rerun", selection_mode="points", key="ptable",
                            config={"displayModeBar": False})
    try:
        pts = event.selection.points
        if pts:
            new_z = elements[pts[0]["point_index"]]["z"]
            if new_z != st.session_state.z:
                st.session_state.z = new_z
                st.rerun()
    except Exception:
        pass

    def on_pick():
        st.session_state.z = st.session_state._pick_z

    st.selectbox(
        "Choose an element", [e["z"] for e in elements],
        index=st.session_state.z - 1,
        format_func=lambda z: f"{z} - {elements[z - 1]['name']} ({elements[z - 1]['symbol']})",
        key="_pick_z", on_change=on_pick,
    )

    el = elements[st.session_state.z - 1]
    color = BLOCK_COLORS.get(el["block"], "#14213D")
    st.markdown(f"### {el['name']} ({el['symbol']}) "
                f'<span class="chip" style="background:{color}">{el["block"]}-block</span>',
                unsafe_allow_html=True)

    stats = [("Atomic number", str(el["z"])), ("Atomic mass", fmt(el["mass"], " u")),
             ("Period / group", f"{el['period'] or '-'} / {el['group'] or '-'}"),
             ("Electronegativity", fmt(el["en"])), ("Melting point", fmt(el["melt"], " K")),
             ("Boiling point", fmt(el["boil"], " K")), ("Density", fmt(el["density"], " g/cm³")),
             ("Electrons per shell", " · ".join(map(str, el["shells"])))]
    cols = st.columns(4)
    for i, (k, v) in enumerate(stats):
        cols[i % 4].markdown(f'<div class="stat"><div class="k">{k}</div><div class="v">{v}</div></div>',
                             unsafe_allow_html=True)
        if i % 4 == 3:
            cols = st.columns(4)
    if el["econf"]:
        st.markdown(f"**Electron configuration:** `{el['econf']}`")
    if el["desc"]:
        st.write(el["desc"])

    left, right = st.columns(2)
    with left:
        st.markdown("#### 2D · Bohr model")
        st.plotly_chart(bohr_2d(el), use_container_width=True, config={"displayModeBar": False})
    with right:
        st.markdown("#### 3D · Drag to rotate")
        st.plotly_chart(atom_3d(el), use_container_width=True)
    footer()


EXAMPLES = {
    "Water": "O", "Ethanol": "CCO", "Benzene": "c1ccccc1", "Acetic acid": "CC(=O)O",
    "Aspirin": "CC(=O)Oc1ccccc1C(=O)O", "Caffeine": "CN1C=NC2=C1C(=O)N(C(=O)N2C)C",
    "Methane": "C", "Glucose": "OCC1OC(O)C(O)C(O)C1O",
}


def name_to_smiles(name):
    import requests

    url = f"https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/name/{requests.utils.quote(name)}/property/SMILES,IsomericSMILES/JSON"
    r = requests.get(url, timeout=10)
    r.raise_for_status()
    props = r.json()["PropertyTable"]["Properties"][0]
    return props.get("IsomericSMILES") or props.get("SMILES") or props.get("CanonicalSMILES")


def page_molecules():
    from rdkit import Chem
    from rdkit.Chem import AllChem, Descriptors, Draw, Lipinski, rdMolDescriptors
    import py3Dmol

    st.markdown("## Molecule Lab")
    st.caption("Enter a SMILES string, or search a compound by name (needs internet).")

    if "smiles" not in st.session_state:
        st.session_state.smiles = "CCO"

    c1, c2 = st.columns([2, 1])
    with c2:
        ex = st.selectbox("Example molecules", list(EXAMPLES))
        if st.button("Load example", use_container_width=True):
            st.session_state.smiles = EXAMPLES[ex]
            st.rerun()
    with c1:
        name = st.text_input("Search by name", placeholder="e.g. paracetamol, ibuprofen")
        if name and st.button("Find compound"):
            try:
                st.session_state.smiles = name_to_smiles(name)
                st.rerun()
            except Exception:
                st.error("Could not find that compound. Check the spelling or enter a SMILES string.")
        st.session_state.smiles = st.text_input("SMILES", value=st.session_state.smiles)

    mol = Chem.MolFromSmiles(st.session_state.smiles)
    if mol is None:
        st.error("This SMILES string is not valid. Check brackets and ring numbers, then try again.")
        footer()
        return
    st.success("Valid molecular structure")

    molh = Chem.AddHs(mol)
    d = [("Formula", rdMolDescriptors.CalcMolFormula(mol)),
         ("Molecular weight", f"{Descriptors.MolWt(mol):.2f}"),
         ("LogP", f"{Descriptors.MolLogP(mol):.2f}"),
         ("TPSA", f"{rdMolDescriptors.CalcTPSA(mol):.2f}"),
         ("H-bond donors", str(Lipinski.NumHDonors(mol))),
         ("H-bond acceptors", str(Lipinski.NumHAcceptors(mol))),
         ("Rotatable bonds", str(Lipinski.NumRotatableBonds(mol))),
         ("Atoms (with H)", str(molh.GetNumAtoms()))]
    cols = st.columns(4)
    for i, (k, v) in enumerate(d):
        cols[i % 4].markdown(f'<div class="stat"><div class="k">{k}</div><div class="v">{v}</div></div>',
                             unsafe_allow_html=True)
        if i % 4 == 3:
            cols = st.columns(4)

    left, right = st.columns(2)
    with left:
        st.markdown("#### 2D structure")
        st.image(Draw.MolToImage(mol, size=(560, 460)), use_container_width=True)
    with right:
        st.markdown("#### 3D structure")
        style = st.selectbox("Model style", ["Ball and stick", "Stick", "Space filling", "Wireframe"])
        if AllChem.EmbedMolecule(molh, randomSeed=42) == -1:
            st.warning("A 3D structure could not be generated for this molecule.")
        else:
            try:
                AllChem.MMFFOptimizeMolecule(molh)
            except Exception:
                pass
            view = py3Dmol.view(width=560, height=460)
            view.addModel(Chem.MolToMolBlock(molh), "mol")
            styles = {
                "Ball and stick": {"stick": {"radius": 0.15}, "sphere": {"scale": 0.28}},
                "Stick": {"stick": {}},
                "Space filling": {"sphere": {}},
                "Wireframe": {"line": {}},
            }
            view.setStyle(styles[style])
            view.setBackgroundColor("#F6F8FB")
            view.zoomTo()
            components.html(view._make_html(), height=470)
    footer()


SYSTEM_PROMPT = (
    "You are ChemBot, a friendly chemistry tutor inside a student learning website. Explain "
    "concepts clearly in simple language with short examples. Keep answers under 180 words unless "
    "the student asks for more. Write formulas in plain text or unicode (H₂O). If a question is "
    "not about chemistry or science, politely steer back to chemistry."
)
MODEL = os.getenv("CHEMBOT_MODEL", "claude-sonnet-5-5")


def get_api_key():
    try:
        if "ANTHROPIC_API_KEY" in st.secrets:
            return st.secrets["ANTHROPIC_API_KEY"]
    except Exception:
        pass
    return os.getenv("ANTHROPIC_API_KEY")


def stream_answer(history):
    import anthropic

    client = anthropic.Anthropic(api_key=get_api_key())
    with client.messages.stream(model=MODEL, max_tokens=700, system=SYSTEM_PROMPT,
                                messages=history) as stream:
        for text in stream.text_stream:
            yield text


def page_chat():
    st.markdown("## ChemBot")
    st.caption("Ask any chemistry doubt: bonding, reactions, periodic trends, organic naming and more.")

    if not get_api_key():
        st.info("ChemBot needs an API key. Add ANTHROPIC_API_KEY to .streamlit/secrets.toml "
                "(or to your deployment's Secrets) and reload.")
    if "chat" not in st.session_state:
        st.session_state.chat = []

    ideas = ["Why is water polar?", "Explain hybridisation simply", "What is electronegativity?"]
    cols = st.columns(len(ideas))
    clicked = None
    for col, q in zip(cols, ideas):
        if col.button(q, use_container_width=True):
            clicked = q

    for m in st.session_state.chat:
        with st.chat_message(m["role"]):
            st.markdown(m["content"])

    prompt = st.chat_input("Type your chemistry question") or clicked
    if prompt:
        st.session_state.chat.append({"role": "user", "content": prompt})
        with st.chat_message("user"):
            st.markdown(prompt)
        with st.chat_message("assistant"):
            if not get_api_key():
                reply = "I cannot answer yet because no API key is set. See the note above."
                st.markdown(reply)
            else:
                try:
                    reply = st.write_stream(stream_answer(st.session_state.chat[-12:]))
                except Exception:
                    reply = "Something went wrong while contacting the AI service. Please try again."
                    st.markdown(reply)
        st.session_state.chat.append({"role": "assistant", "content": reply})
    footer()


# ----------------------------------------------------------------------------
# Navigation
# ----------------------------------------------------------------------------
PAGES = {
    "🏠 Home": page_home,
    "⚛️ Element Explorer": page_elements,
    "🧬 Molecule Lab": page_molecules,
    "🤖 ChemBot": page_chat,
}

with st.sidebar:
    st.markdown("## 🧪 AtomScape")
    choice = st.radio("Navigate", list(PAGES), label_visibility="collapsed")
    st.markdown("---")
    st.caption(f"Created by {CREATOR}")

PAGES[choice]()
